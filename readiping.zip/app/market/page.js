export default function Market() {
    return (
      <div className="wait-page">
        <div>
            <div className="wait-title">
                개발중인 페이지 입니다
            </div>
            <div className="wait-sub">
                조금만 기다려 주세요...!
            </div>
        </div>
      </div>
    )
  }